library(testthat)
library(eucstar)

test_check("eucstar")
